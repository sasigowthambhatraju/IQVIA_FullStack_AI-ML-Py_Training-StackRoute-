# rest-api-microservice-docker
An example of a RESTful API Deployed on a Docker Container
